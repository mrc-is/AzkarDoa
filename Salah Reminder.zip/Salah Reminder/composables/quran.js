// https://api.quran.com/api/v4/chapters/{chapter_id}/info?language=en   1-114

// https://api.quran.com/api/v4/reshort_texts/languages  minden nyelv : iso_code

function getRandomChapterNumber() {
  // Generate a random number between 1 and 114
  return Math.floor(Math.random() * 114) + 1;
}

async function getQuranByChapterNumber(chapterId) {
  return new Promise(async (resolve, reject) => {
    const url = `https://al-quran1.p.rapidapi.com/${chapterId}`;
    const options = {
      method: "GET",
      headers: {
        "X-RapidAPI-Key": "fd463dbab4msh7fcce643e976df7p1dfb72jsnea637ca54859",
        "X-RapidAPI-Host": "al-quran1.p.rapidapi.com",
      },
    };
    try {
      const response = await fetch(url, options);
      const result = await response.json();
      // console.log(result);
      saveQuranText(result);
    } catch (error) {
      console.error(error);
    }
  });
}

async function setQuranComponentText() {
  var topic = document.getElementById("quranContainerTopicTitle");
  var button = document.getElementById("openQuranWindow");

  console.log("chapter number " + chapterNumber);

  getLanguage().then((secondaryLanguage) => {
    if (secondaryLanguage === Language.AR) {
      topic.innerText = "القرآن - الفصل " + chapterNumber;
      button.innerText = "اقرأ فصلًا من القرآن الكريم.";
    }
    if (secondaryLanguage === Language.EN) {
      topic.innerText = "Quran - Chapter: " + chapterNumber;
      button.innerText = "Read a chapter from the holy Quran";
    }
    if (secondaryLanguage === Language.UR) {
      topic.innerText = "قرآن - باب " + chapterNumber;
      button.innerText = "مقدس قرآن سے ایک حصہ پڑھیں۔";
    }
    if (secondaryLanguage === Language.ID) {
      topic.innerText = "Al-Quran - Bab " + chapterNumber;
      button.innerText = "Bacalah satu bab dari Al-Quran yang suci.";
    }
  });
}

function openQuranPopup() {
  chrome.windows.create({
    url: "./components/quranPopup.html?parameterName=quranText",
    type: "popup",
    width: 950,
    height: 700,
  });
}

function setQuranBtnAction() {
  document.getElementById("openQuranWindow").addEventListener("click", () => {
    openQuranPopup();
  });

  document.getElementById("nextQuranPage").addEventListener("click", () => {
    chapterNumber += 1;

    setQuranComponentText();
    getQuranByChapterNumber(chapterNumber);
  });
  document.getElementById("previousQuranPage").addEventListener("click", () => {
    chapterNumber -= 1;

    setQuranComponentText();
    getQuranByChapterNumber(chapterNumber);
  });
}

function saveQuranText(data) {
  chrome.storage.local.set({ result: data });
  chrome.storage.local.set({ chapterNumber: chapterNumber });
}

var chapterNumber = getRandomChapterNumber();

function setUpQuranComponent() {
  setQuranComponentText();
  setQuranBtnAction();
  getQuranByChapterNumber(chapterNumber);
}
