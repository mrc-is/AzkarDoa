async function getLanguage() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get("language", (res) => {
      if (res.language != undefined) {
        resolve(res.language);
      }
      resolve(Language.EN);
    });
  });
}

function changeLanguage(code) {
  chrome.storage.local.set({ language: code });
  showDefaultDetails();
  changeBtnLabelByLanguage();
  if (isItFriday()) {
    setCharityForm();
  }
  setComponentText(); // mekka live
  setQuranComponentText(); // quran component
  setUpSponsorsComponent(); // sponsors
}

/**
 * Load and save all the important data
 *
 */
function startUp() {
  // get local sotrage
  // get local timezone
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  chrome.storage.local.set({
    // will update local time all time if the app is opened
    timezone: timeZone,
  });
  updatePrayingTime();
}

/**
 * Get saved praying timeline as list of Date()
 */
async function getPrayingTimeline() {
  console.log("getPrayingTimeline()");
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(null, (res) => {
      const prayerTimeline = [];

      if (res == undefined || res.praytime == undefined) {
        return [];
      }
      // get praytime
      var firstPray = res.praytime.fajr;
      var secondPray = res.praytime.dhuhr;
      var thirdPay = res.praytime.asr;
      var fourthPray = res.praytime.maghrib;
      var fifthPray = res.praytime.isha;
      // create alarmDate and set alarm
      var firstAlarmDate = convertTimeStringToAlarmDate(firstPray);
      prayerTimeline.push(firstAlarmDate);

      var secondAlarmDate = convertTimeStringToAlarmDate(secondPray);
      prayerTimeline.push(secondAlarmDate);

      var thirdAlarmDate = convertTimeStringToAlarmDate(thirdPay);
      prayerTimeline.push(thirdAlarmDate);

      var fourthAlarmDate = convertTimeStringToAlarmDate(fourthPray);
      prayerTimeline.push(fourthAlarmDate);

      var fifthAlarmDate = convertTimeStringToAlarmDate(fifthPray);
      prayerTimeline.push(fifthAlarmDate);
      resolve(prayerTimeline);
    });
  });
}

function openCharityWindow() {
  chrome.tabs.create({
    url: "https://www.buymeacoffee.com/salahPrayerReminder",
  });
}

function isItFriday() {
  const today = new Date();
  const dayOfWeek = today.getDay(); // Returns a number (0-6) representing the day of the week (0 for Sunday, 1 for Monday, ..., 6 for Saturday)

  return dayOfWeek === 2 || dayOfWeek === 5;
}
