function setComponentText() {
  var topic = document.getElementById("mekkaContainerTopicTitle");
  var button = document.getElementById("openMekkaLiveWindow");

  getLanguage().then((secondaryLanguage) => {
    if (secondaryLanguage === Language.AR) {
      topic.innerText = "بث مباشر";
      button.innerText = "افتح البث المباشر";
    } else if (secondaryLanguage === Language.UR) {
      topic.innerText = "مکہ لائیو دیکھیں";
      button.innerText = "لائیو اسٹریم کھولیں";
    } else if (secondaryLanguage === Language.ID) {
      topic.innerText = "Tonton Mekkah Langsung";
      button.innerText = "Buka Siaran Langsung";
    } else {
      topic.innerText = "Watch Mekka Live";
      button.innerText = "Open Live Stream";
    }
  });
}

function setUpBtnActions() {
  document
    .getElementById("openMekkaLiveWindow")
    .addEventListener("click", () => {
      openMekkaLiveWindow();
    });
}

function openMekkaLiveWindow() {
  chrome.windows.create({
    url: "./components/mekkaLivePopup.html",
    type: "popup",
    width: 950,
    height: 700,
  });
}

function setUpMekkaLiveComponent() {
  setComponentText();
  setUpBtnActions();
}
