const Prayers = {
  FIRST_PRAY: "fajr", // 3 am
  SECOND_PRAY: "dhuhr", // 1pm
  THIRD_PRAY: "asr", // 5 pm
  FOURTH_PRAY: "maghrib", // 9 pm
  FIFTH_PRAY: "isha", // 11 pm

  SUNRISE: "shurooq", // 5 am
};

const CUSTOM_ALARM = {
  UPDATE_PRAY_TIME_ALARM_NAME: "updatePrayTime",
};

async function getPrayerTimeJSONByLocation(location) {
  return new Promise(async (resolve, reject) => {
    const url = "https://muslimsalat.p.rapidapi.com/" + location + ".json";
    const options = {
      method: "GET",
      headers: {
        "X-RapidAPI-Key": "fd463dbab4msh7fcce643e976df7p1dfb72jsnea637ca54859",
        "X-RapidAPI-Host": "muslimsalat.p.rapidapi.com",
      },
    };

    try {
      const response = await fetch(url, options);
      const result = await response.text();
      resolve(result);
    } catch (error) {
      console.error(error);
    }
  });
}

function createAlarm() {
  console.log("createAlerts()");

  chrome.storage.local.get(null, (res) => {
    // get praytime
    var firstPray = res.praytime.fajr;
    var secondPray = res.praytime.dhuhr;
    var thirdPay = res.praytime.asr;
    var fourthPray = res.praytime.maghrib;
    var fifthPray = res.praytime.isha;

    var now = new Date();

    // create alarmDate and set alarm
    var firstAlarmDate = convertTimeStringToAlarmDate(firstPray);
    if (firstAlarmDate > now) {
      chrome.alarms.create(Prayers.FIRST_PRAY, {
        when: firstAlarmDate.getTime(),
      });
    }

    var secondAlarmDate = convertTimeStringToAlarmDate(secondPray);
    if (secondAlarmDate > now) {
      chrome.alarms.create(Prayers.SECOND_PRAY, {
        when: secondAlarmDate.getTime(),
      });
    }

    var thirdAlarmDate = convertTimeStringToAlarmDate(thirdPay);
    if (thirdAlarmDate > now) {
      chrome.alarms.create(Prayers.THIRD_PRAY, {
        when: thirdAlarmDate.getTime(),
      });
    }

    var fourthAlarmDate = convertTimeStringToAlarmDate(fourthPray);
    if (fourthAlarmDate > now) {
      chrome.alarms.create(Prayers.FOURTH_PRAY, {
        when: fourthAlarmDate.getTime(),
      });
    }

    var fifthAlarmDate = convertTimeStringToAlarmDate(fifthPray);
    if (fifthAlarmDate > now) {
      chrome.alarms.create(Prayers.FIFTH_PRAY, {
        when: fifthAlarmDate.getTime(),
      });
    }
  });
}

/**
 * Create Date from the praying_time  Ex: "9:04 pm" => Date()
 * */
function convertTimeStringToAlarmDate(timeString) {
  console.log("convertTimeStringToAlarmDate()");

  var hours = parseInt(timeString.split(":")[0]);
  var minutes = parseInt(timeString.split(":")[1].split(" ")[0]);
  var period = timeString.split(" ")[1].toLowerCase();

  if (period === "pm" && hours !== 12) {
    hours += 12;
  } else if (period === "am" && hours === 12) {
    hours = 0;
  }

  var currentDate = new Date();
  var alarmDate = new Date(
    currentDate.getFullYear(),
    currentDate.getMonth(),
    currentDate.getDate(),
    hours,
    minutes,
    0
  );

  return alarmDate;
}

function openPrayWarningPopup() {
  chrome.windows.create({
    url: "./components/prayAlartPopup.html",
    type: "popup",
    width: 700,
    height: 850,
  });
}

function deletePrayerTimeAlarm(name) {
  console.log("deletePrayerTimeAlarm()");

  chrome.alarms.clear(name);
}

async function updatePrayingTime() {
  chrome.storage.local.get(null, async (local) => {
    if (Object.keys(local).length === 0 && local.constructor === Object) {
      // if there is no saved data in local storage no need to update the praytime.
      return;
    }
    if (
      local.praytime != undefined &&
      new Date().getDate() == new Date(local.praytime.date_for).getDate()
    ) {
      // if the pray time is for the same day then noo need to re-create the alarms
      return;
    }
    var timezone = local.timezone;
    var nameOfTheCity = timezone.split("/")[1].replace("_", "");

    getPrayerTimeJSONByLocation(nameOfTheCity).then((json) => {
      var praytime = JSON.parse(json).items[0];
      chrome.storage.local.set({ praytime: praytime });

      createAlarm();
      displayScale();
    });
  });
}

function logAllAlarmTime() {
  chrome.alarms.getAll(function (alarms) {
    alarms.forEach(function (alarm) {
      console.log("Alarm name:", alarm.name);
      console.log(
        "Scheduled time:",
        new Date(alarm.scheduledTime).toLocaleString()
      );
    });
  });
}
