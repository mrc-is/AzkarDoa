function setSponsoreComponentText() {
  var sponsore_topic = document.getElementById("sponsorsContainerTopicTitle");
  var sponsore_button = document.getElementById("openSponsorsWindow");
  var sponsore_body = document.getElementById("sponsor-body-text");
  getLanguage().then((secondaryLanguage) => {
    if (secondaryLanguage === Language.AR) {
      sponsore_topic.innerText = "شكرا لهؤلاء الأشخاص";
      sponsore_button.innerText = "كن راعيًا ";
      sponsore_body.innerText = "كُن راعيا شهريا وسيتم عرض اسمك قريباً.";
    } else if (secondaryLanguage === Language.UR) {
      sponsore_topic.innerText = "ان لوگوں کا شکریہ";
      sponsore_button.innerText = "سپانسر بنیں ";
      sponsore_body.innerText =
        "ماہانہ سپانسر بنیں اور جلد ہی آپ کا نام دکھایا جائے گا۔";
    } else if (secondaryLanguage === Language.ID) {
      sponsore_topic.innerText = "Terima kasih kepada orang-orang ini";
      sponsore_button.innerText = "Menjadi sponsor";
      sponsore_body.innerText =
        "Menjadi sponsor bulanan dan nama Anda akan segera ditampilkan";
    } else {
      sponsore_topic.innerText = "Sponsors of the Salah - Prayer Reminder";
      sponsore_button.innerText = "Become a sponsore";
      sponsore_body.innerText =
        "Become a monthly sponsor and your name will be displayed shortly.";
    }
  });
}

function setUpSponsorBtnActions() {
  document
    .getElementById("openSponsorsWindow")
    .addEventListener("click", () => {
      document.getElementById("openSponsorsWindow").disabled = true;

      chrome.tabs.create({
        url: "https://www.buymeacoffee.com/salahPrayerReminder/membership",
      });
    });
}

function setUpSponsorsComponent() {
  setSponsoreComponentText();
  setUpSponsorBtnActions();
}
