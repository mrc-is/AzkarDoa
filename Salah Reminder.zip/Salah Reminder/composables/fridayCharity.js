function setUpCharityBtn() {
  var charityBtn = document.getElementById("charityBtn");
  charityBtn.addEventListener("click", () => {
    openCharityWindow();
  });
}

function setCharityForm() {
  var element = document.getElementById("charityText");
  var elementTitle = document.getElementById("charityContainerTopicTitle");

  getLanguage().then((secondaryLanguage) => {
    if (secondaryLanguage === Language.AR) {
      elementTitle.innerHTML = "ما هي فوائد إعطاء الصدقة؟";
      element.innerHTML =
        "مَّن ذَا ٱلَّذِى يُقْرِضُ ٱللَّهَ قَرْضًا حَسَنًۭا فَيُضَـٰعِفَهُۥ لَهُۥٓ أَضْعَافًۭا كَثِيرَةًۭ ۚ وَٱللَّهُ يَقْبِضُ وَيَبْصُۜطُ وَإِلَيْهِ تُرْجَعُونَ ٢٤٥";
    } else if (secondaryLanguage === Language.UR) {
      elementTitle.innerHTML = "صدقہ دینے کے کیا فوائد ہیں؟";
      element.innerHTML =
        "اللہ کو کون ہے جو اچھا قرض دینے والا ہو کہ اس کا اچھا بدلہ اس کے لیے دے، بے شمار زیادہ۔ اور اللہ ہی ہے جو پکڑتا ہے اور پھیلاتا ہے، اور تمہاری طرف لوٹایا جائے گا۔ (قرآن 2:245)";
    } else if (secondaryLanguage === Language.ID) {
      elementTitle.innerHTML = "Apa manfaat memberikan sedekah?";
      element.innerHTML =
        "Siapakah yang mau memberikan pinjaman kepada Allah dengan pinjaman yang baik, maka Allah akan melipatkannya untuknya berlipat-lipat banyaknya. Dan Allah menyempitkan dan melapangkan (rizki), dan hanya kepada-Nya kalian akan dikembalikan. (Al-Quran 2:245)";
    } else {
      elementTitle.innerHTML = "What are the benefits of giving sadaqa?";
      element.innerHTML =
        "Allah says in the Qur’an, “Who is it that would loan Allah a goodly loan so He may multiply it for him many times over? And it is Allah who withholds and grants abundance, and to Him you will be returned” (Qur’an, 2: 245)." +
        "The Prophet (peace be upon him) said “Sadaqah extinguishes sin as water extinguishes fire” (Hadith, Tirmidhi). He also said that Allah offers relief on the Day of Judgement for those who give sadaqa: “The believer’s shade on the Day of Resurrection will be their charity” (Hadith, Tirmidhi).";
    }
  });
}

function runOnFriday() {
  if (!isItFriday()) {
    // It's Friday, so run your function here
    // For example, if your function is called "myFunction", you would call it like this:
    document.getElementById("charityOuterContainer").innerHTML = "";
    document.getElementById("charityOuterContainer").style.cssText = "";
  } else {
    setCharityForm();
    setUpCharityBtn();
  }
}
function setUpCharityComponent() {
  runOnFriday();
}
