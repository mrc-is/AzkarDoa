document.addEventListener("DOMContentLoaded", function () {
  // Retrieve the data from chrome.storage.local
  chrome.storage.local.get(["result"], function (result) {
    const data = result.result;
    console.log(data);
    document.getElementById("surah_name").innerText = data.surah_name;
    document.getElementById("surah_name_ar").innerText = data.surah_name_ar;
    document.getElementById("quranPopupDescription").innerText =
      data.description;

    const objectList = Object.values(data.verses);
    displayObjectFields(objectList, "object-list");
  });

  chrome.storage.local.get(["chapterNumber"], function (result) {
    const chapterNumber = result.chapterNumber;
    document.getElementById("quranPopupTitle").innerText =
      "القرآن - الفصل " + chapterNumber;
  });

  // Function to display object fields
  function displayObjectFields(list, targetElementId) {
    const targetElement = document.getElementById(targetElementId);

    list.forEach((item) => {
      const listItem = document.createElement("li");

      listItem.innerHTML = `<p> ${item.content} <br> ${item.translation_eng} </p>`;
      targetElement.appendChild(listItem);
    });
  }
});
