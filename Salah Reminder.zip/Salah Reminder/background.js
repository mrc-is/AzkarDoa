importScripts("./composables/prayResource.js");
const MAX_TIME_DIFFERENCE_MS = 300000; // Maximum allowed difference: 5 minutes

// chrome.alarms.create("myAlarm", {
//   periodInMinutes: 1, // run every minute
// });

chrome.alarms.onAlarm.addListener(function (alarm) {
  if (alarm.name === CUSTOM_ALARM.UPDATE_PRAY_TIME_ALARM_NAME) {
    updatePrayingTime();
  }
  //   if (alarm.name === "myAlarm") {
  //     openPrayWarningPopup();
  //   }
  else {
    const now = Date.now();
    const timeDifference = now - alarm.scheduledTime;

    if (timeDifference <= MAX_TIME_DIFFERENCE_MS) {
      openPrayWarningPopup();
    }
  }
});

// update praytime if the chrome was turned off
chrome.runtime.onStartup.addListener(function () {
  console.log("update praytime if the chrome was turned off");
  updatePrayingTime();
});

// update praytime if the chrome was hibernated before
chrome.runtime.onInstalled.addListener(function (details) {
  console.log("update praytime if the chrome was hibernated before");
  updatePrayingTime();
});

// not user what time the json from api is updated
chrome.alarms.create(CUSTOM_ALARM.UPDATE_PRAY_TIME_ALARM_NAME, {
  periodInMinutes: 300, // run every 3 hours
});
