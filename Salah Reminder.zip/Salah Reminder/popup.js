/**
 * Local Time, Called every minute
 */
function displayLocalTime() {
  console.log("displayLocalTime()");

  const userLocationDiv = document.getElementById("userLocation");
  var now = new Date();
  const timeFlag = Intl.DateTimeFormat().resolvedOptions().timeZone;

  var ora = now.getHours();
  var perc = now.getMinutes();

  var idoString =
    ora.toString().padStart(2, "0") + ":" + perc.toString().padStart(2, "0");
  userLocationDiv.innerHTML = "<h3>" + timeFlag + ": " + idoString + "</h3>";
}

/**
 * Scale
 */
async function displayScale() {
  console.log("displayScale()");
  var prayerTimeline = await getPrayingTimeline();

  const now = new Date();

  const midnight = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate(),
    0,
    0,
    0,
    0
  ); // today midnight
  const tomorrow = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate() + 1,
    0,
    0,
    0,
    0
  );

  const scale = document.querySelector(".scale");
  scale.innerHTML = "";
  const progress = document.createElement("div");
  progress.className = "progress";
  scale.appendChild(progress);

  const percent = ((now - midnight) / (tomorrow - midnight)) * 100;
  const color = `linear-gradient(to right, #008000 ${percent}%, #DCDCDC ${percent}%)`;
  scale.style.background = color;

  var prayNames = [
    "(Fajr) صلاة الفجر",
    "(Dhuhr) صلاة الظهر",
    "(Asr) صلاة العصر",
    "(Maghrib) صلاة المغرب",
    "(Isha) صلاة العشاء",
  ];

  prayerTimeline.forEach((date, index) => {
    const point = document.createElement("div");
    point.classList.add("point");
    const percent = ((date - midnight) / (tomorrow - midnight)) * 100;
    point.style.left = percent + "%";
    point.addEventListener("click", () => {
      console.log(index);
      var detailsDiv = document.getElementById("prayDetails");
      var prayNameDiv = document.getElementById("prayName");

      const formattedDateAR = formatDate(date, "ar-AR");
      const formattedDateUS = formatDate(date, "en-US");
      const formattedDateIN = formatDate(date, "id-ID");
      const formattedDateUR = formatDate(date, "ur");
      prayNameDiv.innerHTML = "<h2>" + prayNames[index] + "</h2>";
      detailsDiv.innerHTML =
        "<h3>" +
        formattedDateAR +
        "<br>" +
        formattedDateIN +
        "<br>" +
        formattedDateUR +
        " <br> <br> (" +
        formattedDateUS +
        ")</h3>";
    });
    scale.appendChild(point);
  });
}

function getTimeLeftToTheNextPray() {
  //todo
  chrome.alarms.getAll(function (alarms) {
    alarms.forEach(function (alarm) {
      console.log("Alarm name: " + alarm.name);
      console.log("Scheduled time: " + new Date(alarm.scheduledTime));
    });
  });
}

function showDefaultDetails() {
  var prayNameDiv = document.getElementById("prayName");
  prayNameDiv.innerHTML = "";

  var detailsDiv = document.getElementById("prayDetails");
  detailsDiv.innerHTML = "";

  getLanguage().then((secondaryLanguage) => {
    var details = "";

    if (secondaryLanguage === Language.EN) {
      details =
        "It is important to pray at the specified times regardless of how busy we are with work or other activities. Prayer is one of the five pillars of Islam and" +
        "the spiritual lifeline of a believer. It restores a person to his or her senses, reminds them of the presence of God and their need for Him, and connects them to the wider Muslim community";
    } else if (secondaryLanguage === Language.ID) {
      details =
        "Penting untuk berdoa pada waktu yang ditentukan terlepas dari seberapa sibuknya kita dengan pekerjaan atau kegiatan lainnya." +
        " Doa adalah salah satu dari lima pilar Islam dan menjadi penghubung spiritual bagi seorang mukmin. Doa mengembalikan seseorang ke akal sehatnya," +
        " mengingatkan mereka akan kehadiran Allah dan kebutuhan mereka kepada-Nya, serta menghubungkan mereka dengan komunitas Muslim yang lebih luas.";
    } else if (secondaryLanguage === Language.UR) {
      details =
        "کام یا دیگر سرگرمیوں کے باوجود مقرر شدہ وقتوں پر نماز ادا کرنا اہم ہے۔ نماز اسلام کے پانچ ستونوں میں سے ایک ہے اور مومن کی روحانی زندگی کا رابطہ ہے۔ نماز کسی کو " +
        "اس کے حواس پر لوٹاتی ہے، انہیں خدا کی حضور کی یاد دلاتی ہے اور ان کی خدا کی ضرورت کی یاد دلاتی ہے، اور انہیں مسلمان برادری سے رابطہ بناتی ہے۔";
    } else if (secondaryLanguage === Language.AR) {
      details = "";
    }

    var textAR =
      "يجب الصلاة في الوقت المحدد بغض النظر عن مدى انشغالنا في العمل أو غيره. فالصلاة هي ركن من أركان الإسلام الخمسة وشريان " +
      "الحياة الروحية للمؤمن. وهي تعيد الإنسان إلى رشده وتذكره بوجود الله وحاجته لله وتربطه بالمجتمع المسلم الآخر.";

    detailsDiv.innerHTML =
      "<h3>" + textAR + "</h3> <br> <br> <h4>" + details + "</h4>";
  });
}

function showMainTextForUnPaidUsers() {
  var prayNameDiv = document.getElementById("prayName");
  prayNameDiv.innerHTML = "";

  var detailsDiv = document.getElementById("prayDetails");
  detailsDiv.innerHTML = "";

  getLanguage().then((secondaryLanguage) => {
    var title = "";
    var text = "";
    var btnText = "";

    if (secondaryLanguage === Language.EN) {
      title = "Get unlimited access";
      text =
        "Our app allows you to easily and efficiently track Salah timings. No more worries about missing prayers or wasting time searching";
      btnText = "Subscribe";
    } else if (secondaryLanguage === Language.ID) {
      title = "Dapatkan akses tanpa batas";
      text =
        "Aplikasi kami memungkinkan Anda untuk dengan mudah dan efisien melacak waktu-waktu Shalat. Tidak perlu khawatir lagi tentang melewatkan salat atau membuang waktu mencarinya.";
      btnText = "Berlangganan";
    } else if (secondaryLanguage === Language.UR) {
      title = "لا حدود للوصول";
      text =
        "ہماری ایپ آپ کو نماز کی اوقات کو آسانی سے اور کارآمدی کے ساتھ ٹریک کرنے کی اجازت دیتی ہے۔ اب نمازیں چھوڑنے یا وقت ضائع کرنے کے بارے میں پریشان ہونے کی ضرورت نہیں.";
      btnText = "سبسکرائب کریں";
    } else if (secondaryLanguage === Language.AR) {
      title = "احصل على وصول غير محدود";
      text =
        "تطبيقنا يتيح لك تتبع أوقات الصلاة بسهولة وكفاءة. لا داعي للقلق بشأن تفويت الصلوات أو إضاعة الوقت في البحث.";
      btnText = "اشترك";
    }

    var h2 = document.createElement("h2");
    h2.id = "payTextTitle";
    h2.innerText = title;
    var p = document.createElement("p");
    p.innerHTML = text;
    prayNameDiv.appendChild(h2);
    prayNameDiv.appendChild(p);
  });
}

function showEidiText() {
  var prayNameDiv = document.getElementById("prayName");
  prayNameDiv.innerHTML = "";

  var detailsDiv = document.getElementById("prayDetails");
  detailsDiv.innerHTML = "";
  getLanguage().then((secondaryLanguage) => {
    var details = "";

    if (secondaryLanguage === Language.EN) {
      details =
        "Giving Eidi to the needy is considered a righteous act recommended by Islam, which helps draw smiles on the faces of the needy and brings joy and happiness into their hearts. " +
        " Remember that Allah loves those who do good and show generosity, so let your Eidi be an opportunity to demonstrate generosity, compassion, and extend assistance to those who are in greater need.";
    } else if (secondaryLanguage === Language.ID) {
      details =
        "Memberikan Eidi kepada yang membutuhkan adalah tindakan mulia yang dianjurkan oleh Islam untuk menyebarkan senyum dan kebahagiaan kepada sesama.";
    } else if (secondaryLanguage === Language.UR) {
      details =
        "محتاجوں کو عیدی دینا ایک نیک عمل ہے جو اسلام کی توصیہ کی جاتی ہے، جو محتاجوں کے چہروں پر مسکان لانے اور دل میں خوشی اور خوشی لانے میں مدد کرتا ہے۔ یاد رکھیں کہ  " +
        "اللہ اچھے کرنے والوں اور سخاوت پسندوں کو پسند کرتا ہے، تو اپنی عیدی کو عطائیت، رحم دلانے اور محتاجوں کی مدد کو بڑھانے کا موقع بنائیں.";
    } else if (secondaryLanguage === Language.AR) {
      details = "";
    }
    var textAR =
      "إن تقديم العيديات للمحتاجين يعد من الأعمال الصالحة التي ينصح بها الإسلام، والتي تساعد في رسم البسمة على وجوه المحتاجين وإدخال الفرح " +
      "والسرور في قلوبهم. وتذكر أن الله تعالى يحب المحسنين والكرماء، فلتكن عيديتك فرصة لإظهار العطاء والشفقة وتوجيه المساعدة إلى من يحتاجها بشكل أكبر";

    detailsDiv.innerHTML =
      "<h3>" + textAR + "</h3> <br> <br> <h4>" + details + "</h4>";
  });
}

function formatDate(date, code) {
  const formattedDate = date.toLocaleString(code, {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "numeric",
    minute: "numeric",
  });
  return formattedDate;
}

const Language = {
  AR: "ar-AR",
  EN: "en-US",
  UR: "ur", // Urdu
  ID: "id-ID", // Indonesian
};

startUp();
displayLocalTime();
displayScale();
setInterval(displayLocalTime, 30000);

showDefaultDetails();
changeBtnLabelByLanguage();

// Set secondary language
document.getElementById("arBtn").addEventListener("click", () => {
  changeLanguage(Language.AR);
});
document.getElementById("enBtn").addEventListener("click", () => {
  changeLanguage(Language.EN);
});
document.getElementById("urBtn").addEventListener("click", () => {
  changeLanguage(Language.UR);
});
document.getElementById("idBtn").addEventListener("click", () => {
  changeLanguage(Language.ID);
});

// Refres Data btn
document.getElementById("refreshBtn").addEventListener("click", () => {
  updatePrayingTime();
});

// set sponsors component flag
var isSponsorsComponentVisable = false;
document.getElementById("sponsorsBtn").addEventListener("click", () => {
  isSponsorsComponentVisable = !isSponsorsComponentVisable;
  const containerBody = document.getElementById("container-content"); // this is where all the components displayed
  const sponsorsComponent = document.getElementById("sponsorsComponent"); // sponsors component

  if (isSponsorsComponentVisable) {
    containerBody.style.display = "none";
    sponsorsComponent.style.display = "block";
  } else {
    containerBody.style.display = "block";
    sponsorsComponent.style.display = "none";
  }
});

// Feedback btn
function changeBtnLabelByLanguage() {
  var rateUsBtn = document.getElementById("rateUsLink");
  var donateBtn = document.getElementById("donateLink");
  var sponsorsBtn = document.getElementById("sponsorsBtn");
  getLanguage().then((secondaryLanguage) => {
    var rateUsBtnText = "";
    var donateBtnText = "";
    sponsorsBtn.innerText = "Sponsors";

    if (secondaryLanguage === Language.EN) {
      rateUsBtnText = "Give us Feedback";
      donateBtnText = "Donate";
    } else if (secondaryLanguage === Language.ID) {
      rateUsBtnText = "Beri kami umpan balik.";
      donateBtnText = "Donasikan";
    } else if (secondaryLanguage === Language.UR) {
      rateUsBtnText = "ہمیں فیڈبیک دیں.";
      donateBtnText = "عطیہ کریں";
    } else if (secondaryLanguage === Language.AR) {
      rateUsBtnText = "أعطنا ملاحظاتك";
      donateBtnText = "تبرع";
    }

    rateUsBtn.innerText = rateUsBtnText;
    donateBtn.innerText = donateBtnText;
  });
}

// Using fetch to load content from quran.html
fetch("components/quran.html")
  .then((response) => response.text())
  .then(function (html) {
    var parser = new DOMParser();
    var doc = parser.parseFromString(html, "text/html");
    var bodyContent = doc.body.innerHTML; // Extract body content
    document.getElementById("quranComponent").innerHTML = bodyContent;

    setUpQuranComponent();
  });

// Using fetch to load content from fridayCharityBtn.html
fetch("components/fridayCharityBtn.html")
  .then((response) => response.text())
  .then(function (html) {
    var parser = new DOMParser();
    var doc = parser.parseFromString(html, "text/html");
    var bodyContent = doc.body.innerHTML; // Extract body content
    document.getElementById("charityComponent").innerHTML = bodyContent;

    setUpCharityComponent();
  });

// Using fetch to load content from mekkaLive.html
fetch("components/mekkaLive.html")
  .then((response) => response.text())
  .then(function (html) {
    var parser = new DOMParser();
    var doc = parser.parseFromString(html, "text/html");
    var bodyContent = doc.body.innerHTML; // Extract body content
    document.getElementById("mekkaLiveComponent").innerHTML = bodyContent;

    setUpMekkaLiveComponent();
  });

// Using fetch to load sponsors.html
fetch("components/sponsors.html")
  .then((response) => response.text())
  .then(function (html) {
    var parser = new DOMParser();
    var doc = parser.parseFromString(html, "text/html");
    var bodyContent = doc.body.innerHTML; // Extract body content
    document.getElementById("sponsorsComponent").innerHTML = bodyContent;

    // if (isSponsorsComponentVisable == true) {
    setUpSponsorsComponent();
    // }
  });
